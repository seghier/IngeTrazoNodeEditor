from pathlib import Path
import hashlib
import zipfile
import subprocess

init_path = Path(r"C:\Users\pc\Documents\GitHub\IngeTrazoNodeEditor\__init__.py")
init_text = init_path.read_text(encoding="utf-8")
init_text = init_text.replace('"version": "1.7.3"', '"version": "1.7.4"')
init_path.write_text(init_text, encoding="utf-8")
print("Bumped __init__.py version to 1.7.4")

# Run build_zip.py
res = subprocess.run(
    [r"C:\Users\pc\AppData\Local\Programs\Python\Python312\python.exe", "build_zip.py"],
    cwd=r"C:\Users\pc\Documents\GitHub\IngeTrazoNodeEditor",
    capture_output=True,
    text=True
)
print(res.stdout)

# Read zip and compute sha256
zip_path = Path(r"C:\Users\pc\Documents\GitHub\IngeTrazoNodeEditor\node_editor.zip")
hasher = hashlib.sha256()
with open(zip_path, "rb") as f:
    while chunk := f.read(65536):
        hasher.update(chunk)
sha = hasher.hexdigest()
print(f"New SHA256: {sha}")

# Update node_editor.toml
toml_path = Path(r"C:\Users\pc\Documents\GitHub\IngeTrazoNodeEditor\node_editor.toml")
toml_text = toml_path.read_text(encoding="utf-8")
toml_text = toml_text.replace('version = "1.7.3"', 'version = "1.7.4"')
toml_text = toml_text.replace('/v1.7.3/node_editor.zip', '/v1.7.4/node_editor.zip')
# Replace sha256 line
import re
toml_text = re.sub(r'sha256 = "[a-f0-9]+"', f'sha256 = "{sha}"', toml_text)
toml_path.write_text(toml_text, encoding="utf-8")
print("Updated node_editor.toml successfully!")
