from pathlib import Path

p = Path(r"C:\Users\pc\Documents\GitHub\IngeTrazoNodeEditor\__init__.py")
text = p.read_text(encoding="utf-8")
text = text.replace('"version": "1.5.0"', '"version": "1.7.0"')
text = text.replace('"author": "Community"', '"author": "seghier"')
p.write_text(text, encoding="utf-8")
print("Updated __init__.py successfully")
