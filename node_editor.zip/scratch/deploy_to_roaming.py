from pathlib import Path
import shutil

src_dir = Path(r"C:\Users\pc\Documents\GitHub\IngeTrazoNodeEditor")
dst_dir = Path(r"C:\Users\pc\AppData\Roaming\IngeTrazo\plugins\node_editor")

files_to_copy = [
    "ui_canvas.py",
    "__init__.py",
    "engine.py",
    "core_types.py",
    "node_base.py",
    "i18n.py",
    "node_editor.toml",
    "node_editor.zip",
    "tests/test_nodes.py",
]

for rel in files_to_copy:
    s = src_dir / rel
    d = dst_dir / rel
    d.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(s, d)
    print(f"Copied {rel}")

# Copy dark and light icons
for sub in ["dark", "light"]:
    s_icons = src_dir / "icons" / sub
    d_icons = dst_dir / "icons" / sub
    d_icons.mkdir(parents=True, exist_ok=True)
    for p in s_icons.glob("*.png"):
        shutil.copy2(p, d_icons / p.name)
    print(f"Synced {sub} icons to Roaming")

print("Deployment to Roaming completed successfully!")
