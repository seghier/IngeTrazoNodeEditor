from pathlib import Path

p = Path("ui_canvas.py")
text = p.read_text(encoding="utf-8")

old = """        self._update_popout_button(self.is_floating())
        else:
            self.btn_popout.setText(tr("⧉ Pop out"))
            self.btn_popout.setToolTip(tr("Pop out into separate window / Dock as tab"))"""

new = """        self._update_popout_button(self.is_floating())"""

assert old in text, "Target string not found!"
text = text.replace(old, new)
p.write_text(text, encoding="utf-8")
print("Fixed dangling else successfully!")
