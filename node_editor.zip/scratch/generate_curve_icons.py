from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(r"C:\Users\pc\Documents\GitHub\IngeTrazoNodeEditor")
DARK_DIR = ROOT / "icons" / "dark"
LIGHT_DIR = ROOT / "icons" / "light"
DARK_DIR.mkdir(parents=True, exist_ok=True)
LIGHT_DIR.mkdir(parents=True, exist_ok=True)

def create_nurbs_icon(theme: str) -> Image.Image:
    # 4x supersampled: 256x256
    img = Image.new("RGBA", (256, 256), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    ctrl_pts = [(40, 200), (80, 50), (180, 50), (220, 200)]
    poly_color = (140, 150, 170, 180) if theme == "dark" else (100, 110, 130, 200)
    curve_color = (97, 175, 239, 255) if theme == "dark" else (33, 115, 205, 255) # Blue / Cyan
    pt_fill = (229, 192, 123, 255) if theme == "dark" else (210, 150, 40, 255) # Yellow/Orange

    # Draw dashed control polygon
    for i in range(len(ctrl_pts) - 1):
        p0, p1 = ctrl_pts[i], ctrl_pts[i+1]
        steps = 10
        for s in range(steps):
            if s % 2 == 0:
                t0 = s / steps
                t1 = (s + 0.8) / steps
                x0 = p0[0] + (p1[0] - p0[0]) * t0
                y0 = p0[1] + (p1[1] - p0[1]) * t0
                x1 = p0[0] + (p1[0] - p0[0]) * t1
                y1 = p0[1] + (p1[1] - p0[1]) * t1
                draw.line([(x0, y0), (x1, y1)], fill=poly_color, width=4)

    # Draw smooth cubic bezier / B-spline curve
    curve_pts = []
    for s in range(101):
        t = s / 100.0
        # Cubic Bezier
        u = 1.0 - t
        x = u**3 * ctrl_pts[0][0] + 3*u**2*t * ctrl_pts[1][0] + 3*u*t**2 * ctrl_pts[2][0] + t**3 * ctrl_pts[3][0]
        y = u**3 * ctrl_pts[0][1] + 3*u**2*t * ctrl_pts[1][1] + 3*u*t**2 * ctrl_pts[2][1] + t**3 * ctrl_pts[3][1]
        curve_pts.append((x, y))

    draw.line(curve_pts, fill=curve_color, width=12, joint="round")

    # Draw control points
    r = 10
    for (x, y) in ctrl_pts:
        draw.ellipse([x - r, y - r, x + r, y + r], fill=pt_fill, outline=(20, 24, 30, 255), width=3)

    img = img.resize((64, 64), Image.Resampling.LANCZOS)
    return img.quantize(colors=64, method=Image.Quantize.FASTOCTREE)

def create_interpolate_icon(theme: str) -> Image.Image:
    img = Image.new("RGBA", (256, 256), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    curve_color = (152, 195, 121, 255) if theme == "dark" else (46, 125, 50, 255) # Green / Emerald
    pt_fill = (224, 108, 117, 255) if theme == "dark" else (198, 40, 40, 255) # Red / Coral points

    # Smooth S-curve passing through points
    # Points on the curve:
    pts_on_curve = [(40, 180), (100, 80), (160, 180), (220, 80)]

    # Draw cubic spline through points
    curve_pts = []
    # Two cubic segments
    # Seg 1: (40, 180) to (160, 180)
    for s in range(51):
        t = s / 50.0
        u = 1.0 - t
        # control points for S-curve
        x = u**3 * 40 + 3*u**2*t * 70 + 3*u*t**2 * 90 + t**3 * 130
        y = u**3 * 180 + 3*u**2*t * 60 + 3*u*t**2 * 70 + t**3 * 130
        curve_pts.append((x, y))
    for s in range(51):
        t = s / 50.0
        u = 1.0 - t
        x = u**3 * 130 + 3*u**2*t * 170 + 3*u*t**2 * 190 + t**3 * 220
        y = u**3 * 130 + 3*u**2*t * 190 + 3*u*t**2 * 200 + t**3 * 80
        curve_pts.append((x, y))

    draw.line(curve_pts, fill=curve_color, width=12, joint="round")

    # Sample 4 points on the curve
    key_indices = [0, 28, 70, len(curve_pts) - 1]
    r = 11
    for idx in key_indices:
        x, y = curve_pts[idx]
        draw.ellipse([x - r, y - r, x + r, y + r], fill=pt_fill, outline=(255, 255, 255, 255) if theme=="dark" else (30, 30, 30, 255), width=3)

    img = img.resize((64, 64), Image.Resampling.LANCZOS)
    return img.quantize(colors=64, method=Image.Quantize.FASTOCTREE)

# Save icons
create_nurbs_icon("dark").save(DARK_DIR / "curve.nurbs.png", "PNG", optimize=True)
create_nurbs_icon("light").save(LIGHT_DIR / "curve.nurbs.png", "PNG", optimize=True)
create_interpolate_icon("dark").save(DARK_DIR / "curve.interpolate.png", "PNG", optimize=True)
create_interpolate_icon("light").save(LIGHT_DIR / "curve.interpolate.png", "PNG", optimize=True)

print("Icons generated successfully!")
