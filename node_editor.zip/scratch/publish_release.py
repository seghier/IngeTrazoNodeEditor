import json
from pathlib import Path
import subprocess
import urllib.request
import urllib.error

def get_github_token() -> str:
    p = subprocess.Popen(['git', 'credential', 'fill'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    out, err = p.communicate('protocol=https\nhost=github.com\n\n')
    for line in out.splitlines():
        if line.startswith('password='):
            return line[len('password='):].strip()
    raise RuntimeError("GitHub password/token not found in git credential helper")

def publish():
    token = get_github_token()
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "User-Agent": "Antigravity-Release-Script",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    repo = "seghier/IngeTrazoNodeEditor"
    tag = "v1.7"
    release_name = "v1.7: Mirror, Planes, Midpoint, Center & Multi-Monitor Docking"
    body = """### What's New in v1.7:
- **Transform Mirror Node** (`xform.mirror` / `transform.mirror`): Mirror points, curves, and meshes across arbitrary planes with automatic polygon winding inversion and copy toggle.
- **XY, XZ, YZ Plane Nodes** (`plane.xy`, `plane.xz`, `plane.yz`): Standard Cartesian coordinate planes with right-hand frames, visual boundary previews, and alignment frames.
- **Midpoint Node** (`curve.midpoint` / `point.midpoint`): Exact cumulative 50% curve length point and 2-point midpoint with curve tangent and normal frames.
- **Center Node** (`point.center` / `geometry.center`): High-accuracy polygon area centroid via Green's theorem, closed mesh volume centroid via Divergence theorem, and alignment frames.
- **Enhanced Multi-Monitor & Docking Support**:
  - Independent top-level OS window (`parent=None`) for multi-monitor setups, Aero Snap, and Windows 11 Snap Layouts.
  - Non-destructive `takeCentralWidget()` docking to prevent widget disposal on redock.
  - Dock nesting enabled (`win.setDockNestingEnabled(True)`).
  - Floating window `_DockPlaceholderWidget` preserving IngeTrazo internal tray tab states.
"""

    # Check if release exists
    req = urllib.request.Request(f"https://api.github.com/repos/{repo}/releases/tags/{tag}", headers=headers)
    release_id = None
    upload_url = None
    try:
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            release_id = data.get("id")
            upload_url = data.get("upload_url")
            print(f"Release {tag} already exists (id={release_id})")
    except urllib.error.HTTPError as ex:
        if ex.code == 404:
            print(f"Creating release {tag}...")
            payload = json.dumps({
                "tag_name": tag,
                "name": release_name,
                "body": body,
                "draft": False,
                "prerelease": False
            }).encode("utf-8")
            post_req = urllib.request.Request(
                f"https://api.github.com/repos/{repo}/releases",
                data=payload,
                headers={**headers, "Content-Type": "application/json"}
            )
            with urllib.request.urlopen(post_req) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                release_id = data.get("id")
                upload_url = data.get("upload_url")
                print(f"Created release {tag} (id={release_id})")
        else:
            raise

    # Check assets
    zip_path = Path(r"C:\Users\pc\Documents\GitHub\IngeTrazoNodeEditor\node_editor.zip")
    zip_bytes = zip_path.read_bytes()
    print(f"Zip size: {len(zip_bytes)} bytes")

    # List existing assets and delete if node_editor.zip already uploaded
    assets_req = urllib.request.Request(f"https://api.github.com/repos/{repo}/releases/{release_id}/assets", headers=headers)
    with urllib.request.urlopen(assets_req) as resp:
        assets = json.loads(resp.read().decode("utf-8"))
        for asset in assets:
            if asset.get("name") == "node_editor.zip":
                print(f"Deleting existing asset id={asset['id']}...")
                del_req = urllib.request.Request(f"https://api.github.com/repos/{repo}/releases/assets/{asset['id']}", headers=headers, method="DELETE")
                urllib.request.urlopen(del_req)

    # Upload asset
    raw_upload_url = upload_url.split("{")[0] + "?name=node_editor.zip"
    print(f"Uploading {zip_path.name} to {raw_upload_url}...")
    up_req = urllib.request.Request(
        raw_upload_url,
        data=zip_bytes,
        headers={
            **headers,
            "Content-Type": "application/zip",
            "Content-Length": str(len(zip_bytes))
        }
    )
    with urllib.request.urlopen(up_req) as resp:
        res = json.loads(resp.read().decode("utf-8"))
        print(f"Asset uploaded successfully! Download URL: {res.get('browser_download_url')}")

if __name__ == "__main__":
    publish()
