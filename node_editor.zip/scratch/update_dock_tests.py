from pathlib import Path

p = Path(r"C:\Users\pc\Documents\GitHub\IngeTrazoNodeEditor\tests\test_nodes.py")
text = p.read_text(encoding="utf-8")

old_test = '''        fw = editor._floating_window
        self.assertIsNotNone(fw)
        self.assertTrue(fw.isWindow())
        self.assertEqual(fw.parent(), win) # Owned by IngeTrazo window for auto-close
        self.assertTrue(editor.isVisible()) # Content is visible (not blank/empty)
        self.assertIn("Dock Tab", editor.btn_popout.text())

        # 3. Test multi-monitor and maximize helpers
        editor._toggle_maximize_floating_dock()
        self.assertTrue(fw.isMaximized())
        editor._toggle_maximize_floating_dock()
        self.assertFalse(fw.isMaximized())
        editor._center_floating_window()
        editor._move_floating_to_screen(0)
        self.assertTrue(editor.is_floating())

        # 4. Toggle back into docked tab
        editor._toggle_popout()
        self.assertFalse(editor.is_floating())
        self.assertTrue(dock.isVisible())
        self.assertEqual(dock.widget(), editor)
        self.assertIn("Pop out", editor.btn_popout.text())

        # 5. Pop out again and test window closeEvent re-docking
        editor._toggle_popout()
        self.assertTrue(editor.is_floating())
        fw.close()
        self.assertFalse(editor.is_floating())
        self.assertTrue(dock.isVisible())
        self.assertEqual(dock.widget(), editor)

        # 6. Pop out again and test auto-close when IngeTrazo main window closes
        editor._toggle_popout()
        self.assertTrue(editor.is_floating())
        win.close()'''

new_test = '''        fw = editor._floating_window
        self.assertIsNotNone(fw)
        self.assertTrue(fw.isWindow())
        self.assertIsNone(fw.parent()) # True independent top-level OS window (parent=None) for 2nd monitor and Aero Snap
        self.assertEqual(fw._host_win, win)
        self.assertTrue(editor.isVisible()) # Content is visible (not blank/empty)
        self.assertIn("Dock Tab", editor.btn_popout.text())

        # Verify lightweight placeholder was swapped into IngeTrazo dock
        from ui_canvas import _DockPlaceholderWidget
        self.assertIsInstance(dock.widget(), _DockPlaceholderWidget)

        # 3. Test multi-monitor, screen edge snapping, always-on-top and maximize helpers
        fw.set_always_on_top(True)
        self.assertTrue(getattr(fw, "_always_on_top", False))
        fw.set_always_on_top(False)
        self.assertFalse(getattr(fw, "_always_on_top", False))

        editor._snap_floating_to_screen_edge("left")
        self.assertTrue(editor.is_floating())
        editor._snap_floating_to_screen_edge("right")
        self.assertTrue(editor.is_floating())

        editor._toggle_maximize_floating_dock()
        self.assertTrue(fw.isMaximized())
        editor._toggle_maximize_floating_dock()
        self.assertFalse(fw.isMaximized())
        editor._center_floating_window()
        editor._move_floating_to_screen(0)
        self.assertTrue(editor.is_floating())

        # 4. Toggle back into docked tab
        editor._toggle_popout()
        self.assertFalse(editor.is_floating())
        self.assertTrue(dock.isVisible())
        self.assertEqual(dock.widget(), editor)
        self.assertIn("Pop out", editor.btn_popout.text())

        # 5. Pop out again and test bottom docking inside IngeTrazo
        editor._toggle_popout()
        self.assertTrue(editor.is_floating())
        editor._dock_tab(Qt.DockWidgetArea.BottomDockWidgetArea, tabify_with_tray=False)
        self.assertFalse(editor.is_floating())
        self.assertEqual(dock.widget(), editor)
        self.assertEqual(win.dockWidgetArea(dock), Qt.DockWidgetArea.BottomDockWidgetArea)

        # 6. Pop out again and test window closeEvent re-docking
        editor._toggle_popout()
        self.assertTrue(editor.is_floating())
        fw.close()
        self.assertFalse(editor.is_floating())
        self.assertTrue(dock.isVisible())
        self.assertEqual(dock.widget(), editor)

        # 7. Pop out again and test auto-close when IngeTrazo main window closes
        editor._toggle_popout()
        self.assertTrue(editor.is_floating())
        win.close()'''

assert old_test in text, "old_test target block not found in test_nodes.py"
text = text.replace(old_test, new_test)
p.write_text(text, encoding="utf-8")
print("Updated test_nodes.py successfully!")
