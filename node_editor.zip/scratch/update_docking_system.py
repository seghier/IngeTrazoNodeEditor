# update_docking_system.py
from pathlib import Path

repo_dir = Path(r"C:\Users\pc\Documents\GitHub\IngeTrazoNodeEditor")

# ============================================================================
# 1. Update ui_canvas.py
# ============================================================================
ui_file = repo_dir / "ui_canvas.py"
lines = ui_file.read_text(encoding="utf-8").splitlines()

# 1. Locate NodeEditorFloatingWindow
fw_start = None
for i, l in enumerate(lines):
    if l.startswith("class NodeEditorFloatingWindow(QMainWindow):"):
        fw_start = i
        break
assert fw_start is not None, "NodeEditorFloatingWindow not found"

widget_start = None
for i in range(fw_start, len(lines)):
    if lines[i].startswith("class NodeEditorWidget(QWidget):"):
        widget_start = i
        break
assert widget_start is not None, "NodeEditorWidget not found"

# 2. Locate set_dock and _build_ui inside NodeEditorWidget
set_dock_start = None
for i in range(widget_start, len(lines)):
    if lines[i].startswith("    def set_dock(self, dock: Any) -> None:"):
        set_dock_start = i
        break
assert set_dock_start is not None, "set_dock not found"

build_ui_start = None
for i in range(set_dock_start, len(lines)):
    if lines[i].startswith("    def _build_ui(self) -> None:"):
        build_ui_start = i
        break
assert build_ui_start is not None, "_build_ui not found"

print(f"fw_start: {fw_start}, widget_start: {widget_start}, set_dock_start: {set_dock_start}, build_ui_start: {build_ui_start}")

replacement_fw_lines = '''class _DockPlaceholderWidget(QWidget):
    """
    Lightweight placeholder left inside IngeTrazo's internal QDockWidget while
    the Node Editor is popped out into an external window, keeping IngeTrazo's
    internal tray state 100% valid.
    """
    def __init__(self, editor: "NodeEditorWidget") -> None:
        super().__init__()
        self._editor = editor
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 24, 16, 24)
        lay.setSpacing(10)
        lay.addStretch(1)

        lbl = QLabel(tr("Node Editor is open in an external window."))
        lbl.setWordWrap(True)
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lbl.setStyleSheet("color: #abb2bf; font-size: 12px;")
        lay.addWidget(lbl)

        btn_front = QPushButton(tr("🗔 Bring Window to Front"))
        btn_front.setStyleSheet(
            "background: #3b4252; color: #61afef; border: 1px solid #4c566a; "
            "border-radius: 4px; padding: 6px 12px; font-weight: bold;"
        )
        btn_front.clicked.connect(self._editor.bring_to_front)
        lay.addWidget(btn_front)

        btn_dock = QPushButton(tr("⇲ Dock Back Here"))
        btn_dock.setStyleSheet(
            "background: #2c313a; color: #98c379; border: 1px solid #3e4451; "
            "border-radius: 4px; padding: 6px 12px;"
        )
        btn_dock.clicked.connect(self._editor._dock_tab)
        lay.addWidget(btn_dock)

        lay.addStretch(1)


class NodeEditorFloatingWindow(QMainWindow):
    """
    True top-level OS window (`parent=None`) for multi-monitor & OS Aero Snap support.
    - Supports Windows 11 Snap Layouts, Win+Left/Right monitor edge docking,
      4-corner/edge resizing, and independent second-monitor placement.
    - Automatically closes when IngeTrazo's main window closes.
    - Re-docks cleanly into IngeTrazo's side tray when closed by the user.
    """
    def __init__(self, editor: "NodeEditorWidget") -> None:
        # Use parent=None so the OS treats this as an independent monitor-dockable window
        super().__init__(None)
        self._editor = editor
        self._host_win = editor.get_main_window()
        self._is_host_closing = False
        self._always_on_top = False

        self.setWindowFlags(
            Qt.WindowType.Window
            | Qt.WindowType.WindowSystemMenuHint
            | Qt.WindowType.WindowMinMaxButtonsHint
            | Qt.WindowType.WindowCloseButtonHint
        )
        self.setWindowTitle(tr("IngeTrazo — Parametric Node Editor"))
        self.setMinimumSize(420, 300)
        self.resize(1180, 720)

        if self._host_win is not None:
            try:
                self._host_win.installEventFilter(self)
                self._host_win.destroyed.connect(self._on_host_destroyed)
            except Exception:
                pass
            if hasattr(self._host_win, "windowIcon") and not self._host_win.windowIcon().isNull():
                self.setWindowIcon(self._host_win.windowIcon())

        qapp = QApplication.instance()
        if qapp is not None:
            try:
                qapp.aboutToQuit.connect(self._on_host_destroyed)
            except Exception:
                pass

    def set_always_on_top(self, enabled: bool) -> None:
        self._always_on_top = bool(enabled)
        was_visible = self.isVisible()
        flags = self.windowFlags()
        if self._always_on_top:
            flags |= Qt.WindowType.WindowStaysOnTopHint
        else:
            flags &= ~Qt.WindowType.WindowStaysOnTopHint
        self.setWindowFlags(flags)
        if was_visible:
            self.show()
            self.raise_()
            self.activateWindow()

    def _on_host_destroyed(self) -> None:
        self._is_host_closing = True
        try:
            self.close()
        except RuntimeError:
            pass

    def eventFilter(self, obj: Any, event: Any) -> bool:
        if self._host_win is not None and obj == self._host_win:
            if event.type() == QEvent.Type.Close:
                self._is_host_closing = True
                try:
                    self.close()
                except RuntimeError:
                    pass
        return super().eventFilter(obj, event)

    def closeEvent(self, event: Any) -> None:
        if self._is_host_closing:
            event.accept()
        else:
            event.ignore()
            self._editor._dock_tab()
'''.splitlines()

replacement_dock_lines = '''    def set_dock(self, dock: Any) -> None:
        self._dock = dock
        self._preferred_dock_width: int = 560
        self._saved_tray_width: Optional[int] = None
        if dock is not None:
            # Allow unrestricted resizing of the dock inside IngeTrazo
            dock.setMinimumWidth(200)
            dock.setMaximumWidth(16777215)
            dock.setMinimumHeight(160)
            dock.setMaximumHeight(16777215)
            try:
                from PySide6.QtWidgets import QDockWidget
                dock.setAllowedAreas(Qt.DockWidgetArea.AllDockWidgetAreas)
                dock.setFeatures(
                    QDockWidget.DockWidgetFeature.DockWidgetMovable
                    | QDockWidget.DockWidgetFeature.DockWidgetFloatable
                    | QDockWidget.DockWidgetFeature.DockWidgetClosable
                )
                dock.visibilityChanged.connect(self._on_dock_visibility_changed)
            except Exception:
                pass
        self._update_popout_button(self.is_floating())

    def _on_dock_visibility_changed(self, visible: bool) -> None:
        """
        Preserves IngeTrazo's normal side-tray width for other tabs while allowing
        the Node Editor tab to have its own wider resizable width when active.
        """
        if self.is_floating() or self._dock is None:
            return
        win = self.get_main_window()
        if win is None or not hasattr(win, "resizeDocks"):
            return
        tray = getattr(win, "tray", None)
        try:
            if visible:
                if tray is not None and tray.width() > 100 and self._saved_tray_width is None:
                    self._saved_tray_width = tray.width()
                if win.dockWidgetArea(self._dock) in (
                    Qt.DockWidgetArea.RightDockWidgetArea,
                    Qt.DockWidgetArea.LeftDockWidgetArea,
                ):
                    target_w = max(self._preferred_dock_width, self._dock.width())
                    QTimer.singleShot(0, lambda: win.resizeDocks([self._dock], [target_w], Qt.Orientation.Horizontal))
            else:
                if self._dock.width() > 260:
                    self._preferred_dock_width = self._dock.width()
                if tray is not None and self._saved_tray_width:
                    restore_w = self._saved_tray_width
                    QTimer.singleShot(0, lambda: win.resizeDocks([tray], [restore_w], Qt.Orientation.Horizontal))
        except Exception:
            pass

    def bring_to_front(self) -> None:
        if self.is_floating():
            if self._floating_window is not None:
                self._floating_window.show()
                self._floating_window.raise_()
                self._floating_window.activateWindow()
        elif self._dock is not None:
            self._dock.show()
            self._dock.raise_()
            self._dock.activateWindow()

    def _update_popout_button(self, is_floating: bool) -> None:
        if hasattr(self, "btn_popout"):
            self.btn_popout.setText(tr("⇲ Dock Tab") if is_floating else tr("⧉ Pop out"))
            self.btn_popout.setToolTip(
                tr("Dock back as side tray tab (Right-click for monitor options)") if is_floating
                else tr("Pop out into movable floating window (multi-monitor support)")
            )

    def _pop_out(self, target_screen_idx: Optional[int] = None) -> None:
        if self._floating_window is None:
            self._floating_window = NodeEditorFloatingWindow(self)

        # 1. Swap placeholder into IngeTrazo's dock so IngeTrazo's internal references stay valid
        if self._dock is not None:
            if self._placeholder is None:
                self._placeholder = _DockPlaceholderWidget(self)
            try:
                if self._dock.width() > 260:
                    self._preferred_dock_width = self._dock.width()
                self._dock.setWidget(self._placeholder)
                self._dock.hide()
                # Activate IngeTrazo's main tray tab if available so the side tray isn't blank
                win = self.get_main_window()
                tray = getattr(win, "tray", None) if win else None
                if tray is not None:
                    tray.raise_()
            except Exception:
                pass

        # 2. Attach self to the floating window
        self._floating_window.setCentralWidget(self)
        self.show()

        # 3. Restore geometry or place on requested monitor (auto-uses 2nd monitor if requested)
        screens = QGuiApplication.screens()
        if target_screen_idx is not None and 0 <= target_screen_idx < len(screens):
            self._move_floating_to_screen(target_screen_idx)
        elif self._last_floating_geo:
            self._floating_window.restoreGeometry(self._last_floating_geo)
        else:
            self._floating_window.resize(1180, 720)

        self._floating_window.show()
        self.show()
        self._floating_window.raise_()
        self._floating_window.activateWindow()
        self._update_popout_button(True)

    def _dock_tab(self, area: Qt.DockWidgetArea = Qt.DockWidgetArea.RightDockWidgetArea, tabify_with_tray: bool = True) -> None:
        fw = self._floating_window
        if fw is not None:
            try:
                if fw.isVisible():
                    self._last_floating_geo = fw.saveGeometry()
                # CRITICAL: takeCentralWidget() detaches `self` WITHOUT calling deleteLater()!
                if fw.centralWidget() is self:
                    fw.takeCentralWidget()
                fw.hide()
            except (RuntimeError, Exception):
                pass

        if self._dock is not None:
            try:
                self._dock.setWidget(self)
                self.show()

                win = self.get_main_window()
                if win is not None:
                    tray = getattr(win, "tray", None)
                    if tabify_with_tray and tray is not None:
                        # Hide dock title bar so it blends seamlessly with IngeTrazo's tray tabs
                        self._dock.setTitleBarWidget(QWidget(self._dock))
                        win.addDockWidget(win.dockWidgetArea(tray), self._dock)
                        win.tabifyDockWidget(tray, self._dock)
                    else:
                        # Show native dock title bar when docked to Bottom / Left / Right split
                        self._dock.setTitleBarWidget(None)
                        win.addDockWidget(area, self._dock)
                        if area == Qt.DockWidgetArea.BottomDockWidgetArea and hasattr(win, "resizeDocks"):
                            QTimer.singleShot(0, lambda: win.resizeDocks([self._dock], [320], Qt.Orientation.Vertical))

                self._dock.setFloating(False)
                self._dock.show()
                self._dock.raise_()
            except Exception:
                pass

        self._update_popout_button(False)

    def _toggle_popout(self) -> None:
        if self.is_floating():
            self._dock_tab()
        else:
            self._pop_out()

    def _snap_floating_to_screen_edge(self, side: str) -> None:
        """Snaps/docks the floating window to Left, Right, Top, or Bottom half of its current monitor."""
        if not self.is_floating():
            self._pop_out()
        fw = self._floating_window
        if fw is None:
            return
        scr = fw.screen() or QGuiApplication.primaryScreen()
        if scr is None:
            return
        avail = scr.availableGeometry()
        fw.showNormal()
        if side == "left":
            fw.setGeometry(avail.x(), avail.y(), avail.width() // 2, avail.height())
        elif side == "right":
            w = avail.width() // 2
            fw.setGeometry(avail.x() + avail.width() - w, avail.y(), w, avail.height())
        elif side == "top":
            fw.setGeometry(avail.x(), avail.y(), avail.width(), avail.height() // 2)
        elif side == "bottom":
            h = avail.height() // 2
            fw.setGeometry(avail.x(), avail.y() + avail.height() - h, avail.width(), h)
        fw.raise_()
        fw.activateWindow()

    def _show_popout_menu(self, pos: QPoint) -> None:
        """Displays multi-monitor, screen edge docking, and IngeTrazo dock area options."""
        menu = QMenu(self)
        menu.setStyleSheet("""
            QMenu {
                background: #21252b;
                color: #eceff4;
                border: 1px solid #3b4252;
                padding: 4px;
            }
            QMenu::item {
                padding: 5px 20px 5px 24px;
                border-radius: 3px;
            }
            QMenu::item:selected {
                background: #3b4252;
                color: #61afef;
            }
        """)

        is_fl = self.is_floating()
        act_toggle = menu.addAction(tr("⇲ Dock as Side Tray Tab") if is_fl else tr("⧉ Pop out into Movable Window"))
        act_toggle.triggered.connect(self._toggle_popout)

        screens = QGuiApplication.screens()
        if len(screens) > 1:
            m_menu = menu.addMenu(tr("🖥️ Open / Move to Monitor…"))
            m_menu.setStyleSheet(menu.styleSheet())
            curr_screen = self._floating_window.screen() if (is_fl and self._floating_window) else None
            for idx, scr in enumerate(screens):
                geo = scr.availableGeometry()
                scr_title = f"{tr('Monitor')} {idx + 1}: {scr.name()} ({geo.width()}×{geo.height()})"
                if curr_screen and scr == curr_screen:
                    scr_title += f" [{tr('Current')}]"
                a = m_menu.addAction(scr_title)
                a.triggered.connect(lambda checked=False, s_idx=idx: (
                    self._move_floating_to_screen(s_idx) if self.is_floating() else self._pop_out(target_screen_idx=s_idx)
                ))

        # Monitor Edge Snap submenu (works on any OS and any monitor)
        snap_menu = menu.addMenu(tr("📐 Snap Window to Monitor Edge…"))
        snap_menu.setStyleSheet(menu.styleSheet())
        snap_menu.addAction(tr("⬅️ Left Half of Screen"), lambda: self._snap_floating_to_screen_edge("left"))
        snap_menu.addAction(tr("➡️ Right Half of Screen"), lambda: self._snap_floating_to_screen_edge("right"))
        snap_menu.addAction(tr("⬆️ Top Half of Screen"), lambda: self._snap_floating_to_screen_edge("top"))
        snap_menu.addAction(tr("⬇️ Bottom Half of Screen"), lambda: self._snap_floating_to_screen_edge("bottom"))

        # Internal IngeTrazo Dock Area submenu
        if self._dock is not None:
            dock_menu = menu.addMenu(tr("⚓ Dock Inside IngeTrazo…"))
            dock_menu.setStyleSheet(menu.styleSheet())
            dock_menu.addAction(
                tr("📑 Side Tray Tab (Default)"),
                lambda: self._dock_tab(Qt.DockWidgetArea.RightDockWidgetArea, tabify_with_tray=True),
            )
            dock_menu.addAction(
                tr("⬇️ Bottom Panel (Below Viewport)"),
                lambda: self._dock_tab(Qt.DockWidgetArea.BottomDockWidgetArea, tabify_with_tray=False),
            )
            dock_menu.addAction(
                tr("⬅️ Left Side Panel"),
                lambda: self._dock_tab(Qt.DockWidgetArea.LeftDockWidgetArea, tabify_with_tray=False),
            )
            dock_menu.addAction(
                tr("➡️ Right Split Panel"),
                lambda: self._dock_tab(Qt.DockWidgetArea.RightDockWidgetArea, tabify_with_tray=False),
            )

        if is_fl and self._floating_window is not None:
            fw = self._floating_window
            menu.addSeparator()
            act_pin = menu.addAction(tr("📌 Always on Top"))
            act_pin.setCheckable(True)
            act_pin.setChecked(getattr(fw, "_always_on_top", False))
            act_pin.toggled.connect(fw.set_always_on_top)

            act_center = menu.addAction(tr("🎯 Center on Current Screen"))
            act_center.triggered.connect(self._center_floating_window)

            act_max = menu.addAction(tr("🗗 Restore Window Size") if fw.isMaximized() else tr("🗖 Maximize Window"))
            act_max.triggered.connect(self._toggle_maximize_floating_dock)

            act_reset = menu.addAction(tr("↺ Reset Window Size (1180 × 720)"))
            act_reset.triggered.connect(lambda: fw.resize(1180, 720))

        if hasattr(menu, "exec"):
            menu.exec(self.btn_popout.mapToGlobal(pos))
        else:
            menu.exec_(self.btn_popout.mapToGlobal(pos))

    def _move_floating_to_screen(self, screen_idx: int) -> None:
        fw = self._floating_window
        if fw is None:
            return
        screens = QGuiApplication.screens()
        if 0 <= screen_idx < len(screens):
            scr = screens[screen_idx]
            avail = scr.availableGeometry()
            if fw.isMaximized():
                fw.showNormal()
            w = min(1200, int(avail.width() * 0.9))
            h = min(800, int(avail.height() * 0.9))
            x = avail.x() + (avail.width() - w) // 2
            y = avail.y() + (avail.height() - h) // 2
            fw.setGeometry(x, y, w, h)
            fw.show()
            fw.raise_()
            fw.activateWindow()

    def _center_floating_window(self) -> None:
        fw = self._floating_window
        if fw is None:
            return
        scr = fw.screen() if hasattr(fw, "screen") else None
        if scr is not None:
            avail = scr.availableGeometry()
            if fw.isMaximized():
                fw.showNormal()
            w = min(fw.width(), int(avail.width() * 0.95))
            h = min(fw.height(), int(avail.height() * 0.95))
            x = avail.x() + (avail.width() - w) // 2
            y = avail.y() + (avail.height() - h) // 2
            fw.setGeometry(x, y, w, h)
            fw.show()
            fw.raise_()
            fw.activateWindow()

    def _toggle_maximize_floating_dock(self) -> None:
        fw = self._floating_window
        if fw is None:
            return
        if fw.isMaximized():
            fw.showNormal()
        else:
            fw.showMaximized()

    def eventFilter(self, obj: Any, event: Any) -> bool:
        if hasattr(self, "top_bar") and obj == self.top_bar and self.is_floating():
            fw = self._floating_window
            if fw is not None:
                try:
                    if fw.isVisible():
                        if event.type() == QEvent.Type.MouseButtonPress and event.button() == Qt.MouseButton.LeftButton:
                            # Use native OS system move so Windows Aero Snap / monitor docking works!
                            wh = fw.windowHandle()
                            if wh is not None and hasattr(wh, "startSystemMove"):
                                wh.startSystemMove()
                                return True
                            self._bar_drag_pos = event.globalPosition().toPoint() - fw.frameGeometry().topLeft()
                        elif event.type() == QEvent.Type.MouseMove and (event.buttons() & Qt.MouseButton.LeftButton) and hasattr(self, "_bar_drag_pos"):
                            if not fw.isMaximized():
                                fw.move(event.globalPosition().toPoint() - self._bar_drag_pos)
                                return True
                        elif event.type() == QEvent.Type.MouseButtonDblClick and event.button() == Qt.MouseButton.LeftButton:
                            self._toggle_maximize_floating_dock()
                            return True
                except RuntimeError:
                    pass
        return super().eventFilter(obj, event)
'''.splitlines()

new_lines = (
    lines[:fw_start]
    + replacement_fw_lines
    + [""]
    + lines[widget_start:set_dock_start]
    + replacement_dock_lines
    + [""]
    + lines[build_ui_start:]
)

new_text = "\n".join(new_lines)

# Update retranslate_ui line
old_retrans = """        if hasattr(self, "_dock") and self._dock is not None:
            self._update_popout_button(self._dock.isFloating() if hasattr(self._dock, "isFloating") else False)"""
new_retrans = """        self._update_popout_button(self.is_floating())"""

assert old_retrans in new_text, "old_retrans not found in ui_canvas.py"
new_text = new_text.replace(old_retrans, new_retrans)

ui_file.write_text(new_text, encoding="utf-8")
print("ui_canvas.py successfully updated!")

# ============================================================================
# 2. Update __init__.py
# ============================================================================
init_file = repo_dir / "__init__.py"
init_text = init_file.read_text(encoding="utf-8")

old_init_target = """        if win:
            win._node_editor_widget = editor_widget
            win._node_editor_dock = dock
            win._node_editor_bridge = bridge"""

new_init_target = """        if win:
            win._node_editor_widget = editor_widget
            win._node_editor_dock = dock
            win._node_editor_bridge = bridge
            if hasattr(win, "setDockNestingEnabled"):
                try:
                    win.setDockNestingEnabled(True)
                except Exception:
                    pass"""

if old_init_target in init_text:
    init_text = init_text.replace(old_init_target, new_init_target)
    init_file.write_text(init_text, encoding="utf-8")
    print("__init__.py successfully updated!")
else:
    print("old_init_target already updated or not found in __init__.py")
