from pathlib import Path

p = Path(r"C:\Users\pc\Documents\GitHub\IngeTrazoNodeEditor\engine.py")
text = p.read_text(encoding="utf-8")

old_remove = """    def remove_node(self, node_id: str) -> None:
        if node_id not in self.nodes:
            return
        for w in self.wires:"""

new_remove = """    def remove_node(self, node_id: str) -> None:
        if node_id not in self.nodes:
            return
        node = self.nodes[node_id]
        if hasattr(node, "on_destroy") and callable(node.on_destroy):
            try:
                node.on_destroy()
            except Exception:
                pass
        for w in self.wires:"""

old_load = """    def load_dict(self, data: Dict[str, Any]) -> None:
        self.nodes.clear()
        self.wires.clear()"""

new_load = """    def load_dict(self, data: Dict[str, Any]) -> None:
        for n in list(self.nodes.values()):
            if hasattr(n, "on_destroy") and callable(n.on_destroy):
                try:
                    n.on_destroy()
                except Exception:
                    pass
        self.nodes.clear()
        self.wires.clear()"""

assert old_remove in text, "old_remove not found"
assert old_load in text, "old_load not found"

text = text.replace(old_remove, new_remove, 1)
text = text.replace(old_load, new_load, 1)
p.write_text(text, encoding="utf-8")
print("Updated engine.py successfully!")
