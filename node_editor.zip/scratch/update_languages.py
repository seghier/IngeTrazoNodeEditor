import json
from pathlib import Path

lang_dir = Path(r"C:\Users\pc\Documents\GitHub\IngeTrazoNodeEditor\languages")

translations = {
    "en": {
        "NURBS Curve": "NURBS Curve",
        "Interpolate Curve": "Interpolate Curve",
        "Click in Viewport": "Click in Viewport",
        "Viewport Handles": "Viewport Handles",
        "Hide Handles": "Hide Handles",
        "Clear Points": "Clear Points",
        "Control Points": "Control Points",
        "Tension": "Tension",
    },
    "fr": {
        "NURBS Curve": "Courbe NURBS",
        "Interpolate Curve": "Courbe Interpolée",
        "Click in Viewport": "Cliquer dans la Vue",
        "Viewport Handles": "Poignées dans la Vue",
        "Hide Handles": "Masquer Poignées",
        "Clear Points": "Effacer Points",
        "Control Points": "Points de Contrôle",
        "Tension": "Tension",
    },
    "zh": {
        "NURBS Curve": "NURBS 曲线",
        "Interpolate Curve": "插值平滑曲线",
        "Click in Viewport": "在视图中点击插入点",
        "Viewport Handles": "视图控制手柄",
        "Hide Handles": "隐藏手柄",
        "Clear Points": "清除点",
        "Control Points": "控制点",
        "Tension": "张力",
    },
    "ar": {
        "NURBS Curve": "منحنى نيربس (NURBS)",
        "Interpolate Curve": "منحنى استيفاء سلس",
        "Click in Viewport": "انقر في المشهد لإدراج نقاط",
        "Viewport Handles": "مقابض التحكم في المشهد",
        "Hide Handles": "إخفاء المقابض",
        "Clear Points": "مسح النقاط",
        "Control Points": "نقاط التحكم",
        "Tension": "التوتر",
    }
}

for lang_code, trans in translations.items():
    file_path = lang_dir / f"{lang_code}.json"
    if file_path.exists():
        data = json.loads(file_path.read_text(encoding="utf-8"))
        data.update(trans)
        file_path.write_text(json.dumps(data, ensure_ascii=False, indent=4) + "\n", encoding="utf-8")
        print(f"Updated {file_path.name}")
