from pathlib import Path

p = Path(r"C:\Users\pc\Documents\GitHub\IngeTrazoNodeEditor\ui_canvas.py")
text = p.read_text(encoding="utf-8")

old_code = """    def __init__(self, node: BaseNode, on_param_changed: Callable[[str, str, object], None]) -> None:
        super().__init__()
        self.node = node"""

new_code = """    def __init__(self, node: BaseNode, on_param_changed: Callable[[str, str, object], None]) -> None:
        super().__init__()
        self.node = node
        self.node._item_ref = self"""

if old_code in text:
    text = text.replace(old_code, new_code, 1)
    p.write_text(text, encoding="utf-8")
    print("Updated NodeItem.__init__ with _item_ref successfully!")
else:
    print("Target not found in ui_canvas.py!")
